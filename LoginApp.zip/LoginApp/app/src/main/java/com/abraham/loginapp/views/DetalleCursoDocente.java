package com.abraham.loginapp.views;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.abraham.loginapp.R;
import com.abraham.loginapp.views.AsignarTareaActivity;


public class DetalleCursoDocente extends AppCompatActivity {

    private TextView textCursoTitulo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_curso_docente);

        textCursoTitulo = findViewById(R.id.textCursoTitulo);

        String cursoNombre = getIntent().getStringExtra("curso_nombre");
        int cursoId = getIntent().getIntExtra("curso_id", -1);

        if (cursoNombre != null) {
            textCursoTitulo.setText("Opciones para: " + cursoNombre);
        }

        Button btnAsignarTarea = findViewById(R.id.btnAsignarTarea);
        Button btnVerEntregas = findViewById(R.id.btnVerEntregas);
        Button btnCalificar = findViewById(R.id.btnCalificar);
        Button btnAsistencia = findViewById(R.id.btnAsistencia);
        Button btnVolver = findViewById(R.id.btnVolver);

        btnAsignarTarea.setOnClickListener(v -> {
            Intent intent = new Intent(DetalleCursoDocente.this, AsignarTareaActivity.class);
            intent.putExtra("curso_id", cursoId);
            startActivity(intent);
        });

        btnVerEntregas.setOnClickListener(v -> {
            // TODO: implementar
        });

        btnCalificar.setOnClickListener(v -> {
            // TODO: implementar
        });

        btnAsistencia.setOnClickListener(v -> {
            // TODO: implementar
        });

        btnVolver.setOnClickListener(v -> finish());
    }
}
