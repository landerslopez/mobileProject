package com.abraham.loginapp.model;

public class Entrega {
    private int id;
    private int tareaId;
    private int estudianteId;
    private String archivoUri;
    private String tipoArchivo;
    private String fechaEnvio;

    public Entrega(int id, int tareaId, int estudianteId, String archivoUri, String tipoArchivo, String fechaEnvio) {
        this.id = id;
        this.tareaId = tareaId;
        this.estudianteId = estudianteId;
        this.archivoUri = archivoUri;
        this.tipoArchivo = tipoArchivo;
        this.fechaEnvio = fechaEnvio;
    }

    public int getId() { return id; }
    public int getTareaId() { return tareaId; }
    public int getEstudianteId() { return estudianteId; }
    public String getArchivoUri() { return archivoUri; }
    public String getTipoArchivo() { return tipoArchivo; }
    public String getFechaEnvio() { return fechaEnvio; }

    public void setId(int id) { this.id = id; }
    public void setTareaId(int tareaId) { this.tareaId = tareaId; }
    public void setEstudianteId(int estudianteId) { this.estudianteId = estudianteId; }
    public void setArchivoUri(String archivoUri) { this.archivoUri = archivoUri; }
    public void setTipoArchivo(String tipoArchivo) { this.tipoArchivo = tipoArchivo; }
    public void setFechaEnvio(String fechaEnvio) { this.fechaEnvio = fechaEnvio; }
}
