package com.abraham.loginapp.views;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.abraham.loginapp.R;
import com.abraham.loginapp.config.Database;

public class AsignarTareaActivity extends AppCompatActivity {

    private EditText editTitulo, editDescripcion;
    private Button btnGuardar;
    private int cursoId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_asignar_tarea);

        editTitulo = findViewById(R.id.editTituloTarea);
        editDescripcion = findViewById(R.id.editDescripcionTarea);
        btnGuardar = findViewById(R.id.btnGuardarTarea);

        cursoId = getIntent().getIntExtra("curso_id", -1);

        btnGuardar.setOnClickListener(v -> {
            String titulo = editTitulo.getText().toString().trim();
            String descripcion = editDescripcion.getText().toString().trim();

            if (!titulo.isEmpty() && !descripcion.isEmpty()) {
                Database db = new Database(this);  // 🔁 Cambio aquí
                boolean exito = db.insertarTarea(cursoId, titulo, descripcion, ""); // 🔁 Aquí también
                if (exito) {
                    Toast.makeText(this, "Tarea asignada correctamente", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(this, "Error al asignar tarea", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
