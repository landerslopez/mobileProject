package com.abraham.loginapp.model;

public class Calificacion {
    private int id;
    private int tareaId;
    private int estudianteId;
    private int nota;

    public Calificacion(int id, int tareaId, int estudianteId, int nota) {
        this.id = id;
        this.tareaId = tareaId;
        this.estudianteId = estudianteId;
        this.nota = nota;
    }

    public int getId() { return id; }
    public int getTareaId() { return tareaId; }
    public int getEstudianteId() { return estudianteId; }
    public int getNota() { return nota; }

    public void setId(int id) { this.id = id; }
    public void setTareaId(int tareaId) { this.tareaId = tareaId; }
    public void setEstudianteId(int estudianteId) { this.estudianteId = estudianteId; }
    public void setNota(int nota) { this.nota = nota; }
}
