package com.abraham.loginapp.views;


import android.annotation.SuppressLint;
import android.os.Bundle;

import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.abraham.loginapp.R;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.navigation.NavigationView;

public class Docente extends AppCompatActivity {
    private DrawerLayout drawerLayout;
    private MaterialToolbar toolbar;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_docente);

        // Referencias a los elementos de la interfaz
        drawerLayout = findViewById(R.id.drawer_layout);
        toolbar = findViewById(R.id.topAppBar);
        TextView textoNombre = findViewById(R.id.textNombre);

        // Establecer la Toolbar como ActionBar
        setSupportActionBar(toolbar);

        // Obtener el nombre desde el intent
        String nombreUsuario = getIntent().getStringExtra("nombre_usuario");
        if (nombreUsuario != null && !nombreUsuario.isEmpty()) {
            toolbar.setTitle("Bienvenido, " + nombreUsuario); // título en la barra superior
            textoNombre.setText("Hola, " + nombreUsuario);    // texto en el cuerpo de la pantalla
        }

        // Abrir el menú lateral al presionar el ícono de hamburguesa
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_inicio) {
                drawerLayout.closeDrawer(GravityCompat.START);
                return true;

            } else if (id == R.id.nav_areas) {
                Toast.makeText(this, "Áreas seleccionadas", Toast.LENGTH_SHORT).show();
                drawerLayout.closeDrawer(GravityCompat.START);
                return true;

            } else if (id == R.id.nav_asistencia) {
                Toast.makeText(this, "Asistencia seleccionada", Toast.LENGTH_SHORT).show();
                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            }

            return false;

        });

    }
}
