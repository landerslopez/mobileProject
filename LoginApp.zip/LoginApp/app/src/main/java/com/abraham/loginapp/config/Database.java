package com.abraham.loginapp.config;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.abraham.loginapp.model.User;

public class Database extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "usuarios.db";
    private static final int DATABASE_VERSION = 3;

    public Database(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Tabla usuarios
        db.execSQL("CREATE TABLE usuarios (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "nombre TEXT NOT NULL, " +
                "correo TEXT NOT NULL, " +
                "username TEXT NOT NULL UNIQUE, " +
                "password TEXT NOT NULL, " +
                "rol TEXT NOT NULL)");

        // Tabla cursos
        db.execSQL("CREATE TABLE cursos (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "nombre TEXT NOT NULL, " +
                "docente_id INTEGER NOT NULL, " +
                "FOREIGN KEY(docente_id) REFERENCES usuarios(id))");

        // Tabla tareas
        db.execSQL("CREATE TABLE tareas (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "curso_id INTEGER NOT NULL, " +
                "titulo TEXT NOT NULL, " +
                "descripcion TEXT, " +
                "comentario TEXT, " +
                "FOREIGN KEY(curso_id) REFERENCES cursos(id))");

        // Tabla calificaciones
        db.execSQL("CREATE TABLE calificaciones (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "tarea_id INTEGER NOT NULL, " +
                "estudiante_id INTEGER NOT NULL, " +
                "nota INTEGER CHECK(nota BETWEEN 0 AND 20), " +
                "FOREIGN KEY(tarea_id) REFERENCES tareas(id), " +
                "FOREIGN KEY(estudiante_id) REFERENCES usuarios(id))");

        // Tabla entregas
        db.execSQL("CREATE TABLE entregas (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "tarea_id INTEGER NOT NULL, " +
                "estudiante_id INTEGER NOT NULL, " +
                "archivo_uri TEXT NOT NULL, " +
                "tipo_archivo TEXT, " +
                "fecha_envio TEXT, " +
                "FOREIGN KEY(tarea_id) REFERENCES tareas(id), " +
                "FOREIGN KEY(estudiante_id) REFERENCES usuarios(id))");

        // Datos de prueba
        db.execSQL("INSERT INTO usuarios (nombre, correo, username, password, rol) " +
                "VALUES ('Administrador', 'admin@ejemplo.com', 'admin', 'admin', 'docente')");
        db.execSQL("INSERT INTO usuarios (nombre, correo, username, password, rol) " +
                "VALUES ('Juan Pérez', 'juan@ejemplo.com', 'juan', '12345', 'alumno')");
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS entregas");
        db.execSQL("DROP TABLE IF EXISTS calificaciones");
        db.execSQL("DROP TABLE IF EXISTS tareas");
        db.execSQL("DROP TABLE IF EXISTS cursos");
        db.execSQL("DROP TABLE IF EXISTS usuarios");
        onCreate(db);
    }


    public boolean insertUser(String nombre, String correo, String username, String password, String rol) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("nombre", nombre);
        values.put("correo", correo);
        values.put("username", username);
        values.put("password", password);
        values.put("rol", rol);
        long result = db.insert("usuarios", null, values);
        return result != -1;
    }

    public User authenticate(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM usuarios WHERE username = ? AND password = ?", new String[]{username, password});
        if (cursor.moveToFirst()) {
            User user = new User();
            user.setId(cursor.getInt(cursor.getColumnIndexOrThrow("id")));
            user.setNombre(cursor.getString(cursor.getColumnIndexOrThrow("nombre")));
            user.setCorreo(cursor.getString(cursor.getColumnIndexOrThrow("correo")));
            user.setUsername(username);
            user.setPassword(password);
            user.setRole(cursor.getString(cursor.getColumnIndexOrThrow("rol")));
            cursor.close();
            return user;
        }
        cursor.close();
        return null;
    }

    // ✔ Verifica si el nombre de usuario ya existe
    public boolean userExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT id FROM usuarios WHERE username = ?", new String[]{username});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    // ✔ Verifica si la contraseña ya está en uso
    public boolean passwordExists(String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT id FROM usuarios WHERE password = ?", new String[]{password});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    // (Opcional) ✔ Verifica si el correo ya está registrado
    public boolean emailExists(String correo) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT id FROM usuarios WHERE correo = ?", new String[]{correo});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    public boolean insertarCurso(String nombre, int docenteId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("nombre", nombre);
        values.put("docente_id", docenteId);
        long result = db.insert("cursos", null, values);
        return result != -1;
    }
    public Cursor obtenerCursosPorDocente(int docenteId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM cursos WHERE docente_id = ?", new String[]{String.valueOf(docenteId)});
    }
    public boolean insertarTarea(int cursoId, String titulo, String descripcion, String comentario) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("curso_id", cursoId);
        values.put("titulo", titulo);
        values.put("descripcion", descripcion);
        values.put("comentario", comentario);
        long result = db.insert("tareas", null, values);
        return result != -1;
    }
    public Cursor obtenerTareasPorCurso(int cursoId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM tareas WHERE curso_id = ?", new String[]{String.valueOf(cursoId)});
    }
    public boolean insertarCalificacion(int tareaId, int estudianteId, int nota) {
        if (nota < 0 || nota > 20) return false;

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("tarea_id", tareaId);
        values.put("estudiante_id", estudianteId);
        values.put("nota", nota);
        long result = db.insert("calificaciones", null, values);
        return result != -1;
    }
    public Cursor obtenerCalificacionesPorEstudiante(int estudianteId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery(
                "SELECT c.nombre AS curso, t.titulo AS tarea, t.comentario, ca.nota " +
                        "FROM calificaciones ca " +
                        "JOIN tareas t ON ca.tarea_id = t.id " +
                        "JOIN cursos c ON t.curso_id = c.id " +
                        "WHERE ca.estudiante_id = ?",
                new String[]{String.valueOf(estudianteId)}
        );
    }
    public boolean registrarEntrega(int tareaId, int estudianteId, String archivoUri, String tipoArchivo, String fechaEnvio) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("tarea_id", tareaId);
        values.put("estudiante_id", estudianteId);
        values.put("archivo_uri", archivoUri);
        values.put("tipo_archivo", tipoArchivo);
        values.put("fecha_envio", fechaEnvio);
        long result = db.insert("entregas", null, values);
        return result != -1;
    }
    public Cursor obtenerEntregasPorTarea(int tareaId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM entregas WHERE tarea_id = ?", new String[]{String.valueOf(tareaId)});
    }

}