package com.abraham.loginapp.views;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.abraham.loginapp.R;

public class AreasDocenteActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_areas_docente); // Este layout lo crearás ahora
    }
}
