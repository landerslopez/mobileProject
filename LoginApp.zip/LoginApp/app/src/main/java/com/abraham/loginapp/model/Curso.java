package com.abraham.loginapp.model;



public class Curso {
    private int id;
    private String nombre;
    private int docenteId;

    public Curso(int id, String nombre, int docenteId) {
        this.id = id;
        this.nombre = nombre;
        this.docenteId = docenteId;
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public int getDocenteId() { return docenteId; }

    public void setId(int id) { this.id = id; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setDocenteId(int docenteId) { this.docenteId = docenteId; }
}
